package com.cxz.cxzspringboot_web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CxzspringbootWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(CxzspringbootWebApplication.class, args);
    }

}
